import React from 'react'

const AuthContext = () => {
    return (
        <div className='text-blue-200'>AuthContext</div>
    )
}

export default AuthContext