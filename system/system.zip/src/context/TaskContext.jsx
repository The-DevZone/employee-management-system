import React from 'react'

const TaskContext = () => {
    return (
        <div className='text-amber-700'>TaskContext</div>
    )
}

export default TaskContext