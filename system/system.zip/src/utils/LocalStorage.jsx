const Employee = [
    {
        "id": 1,
        "email": "rohit@gmail.com",
        "password": "123"
    },
    {
        "id": 2,
        "email": "monika@gmail.com",
        "password": "123"
    },
    {
        "id": 3,
        "email": "sarthak@gmail.com",
        "password": "123"
    },
    {
        "id": 4,
        "email": "anita@gmail.com",
        "password": "123"
    },
    {
        "id": 5,
        "email": "rahul@gmail.com",
        "password": "123"
    },
]

const Admin = [
    {
        "id": 101,
        "name": "Admin User",
        "email": "admin@example.com",
        "role": "admin",
        "password": "123"
    }
]